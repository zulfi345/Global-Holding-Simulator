# PROGRESS
Terakhir: M-076 selesai | Berikut: M-077

## Aturan sesi
1. Baca file ini lalu MAP.md saja. Detail realisme ada di PROMPT_MASTER.md (di ZIP_LENGKAP); baca bagian yang relevan HANYA jika perlu.
2. Kerjakan mikro-tahap berikut sebanyak yang muat (300-800 token tiap tahap); berhenti SEBELUM token habis.
3. Keluaran = kode + 1 baris status. Tanya dulu jika tidak jelas (maks 3 pertanyaan).
4. Akhir sesi: centang tahap, perbarui MAP.md, kirim (a) M-NNN.zip = proyek LENGKAP dari awal sampai tahap terbaru (NNN = tahap terakhir selesai; pengguna mengganti seluruh repo GitHub dengannya), (b) PAKET_LANJUT.zip baru (PROGRESS.md, MAP.md, file tahap berikut, LANJUT.txt). Jika ada file yang dihapus, tulis di PROGRESS.md baris 'HAPUS: path'.
5. Build via GitHub Actions. Build gagal -> pengguna tempel log -> perbaiki dulu. Claude tidak bisa kompilasi: tulis Kotlin konservatif, tanpa dependensi baru tanpa dicatat.
6. Data nyata: beri tanggal_data + perkiraan=true. Jangan mengarang angka presisi palsu.
7. Jaga file ini <= 60 baris.

## Keputusan tetap
- Target 100 negara (permintaan pengguna): M-028..M-031 menambah 80 negara; semua perkiraan 2026-10
- Game baru dari nol. Kotlin + Jetpack Compose (MVVM). Build GitHub Actions, tanpa Android Studio
- Mata uang Rupiah; kurs asing memengaruhi ekspor/impor
- Modal awal 5 pilihan: Rp20/40/60/80/100 miliar
- 60 usaha + 60 rival swasta (daftar di PROMPT_MASTER.md Lampiran A/B)
- Data: CSV di data/src -> tools/gen_*.py -> JSON di assets/data

## Tahap
- [x] M-001..M-015 fondasi: Gradle/build-apk.yml, Negara.kt+Loader, TemaGame+RankingPdbScreen, MakroEngine, KursEngine, PajakEngine, LabaRugi/Neraca/ArusKas/Akuntansi + uji; semua belum dikompilasi
- [x] M-016..M-027 60 usaha lengkap (usaha.csv 9 arketipe: tambang_energi,pertanian,manufaktur,teknologi,finansial,logistik,properti_konstruksi,ritel_jasa,layanan_regulasi) + Usaha.kt/UsahaLoader.kt + ArketipeUsaha.kt (StrukturBiaya, registry)
- [x] M-028..M-031 negara.csv +80 negara (Eropa, Asia&TimTeng, Afrika, Amerika&Oseania) -> total 100 negara; semua perkiraan 2026-10, kasus khusus dicatat per baris di CSV
- [x] M-032 KursEngine: TERPATOK (12), ZONA_EURO (18, acuan DE), TERKAIT (DK,CI,SN,CM->DE; BN->SG), tickSemua + 4 uji. Catatan: HR (Kroasia) belum ada di data
- [x] M-033..M-041 (F6 selesai) strategi per arketipe usaha, masing2 + test (4-5 uji), terdaftar ArketipeRegistry: StrategiFinansial (NIM/cadangan NPL/CAR), StrategiTambangEnergi (royalti/deplesi/harga), StrategiPertanian (musim panen + HargaKomoditas.kt bersama), StrategiManufaktur (kapasitas/titik impas), StrategiTeknologi (churn/pendapatan berulang), StrategiLogistik (armada/bahan bakar), StrategiPropertiKonstruksi (okupansi/progres proyek), StrategiRitelJasa (lalu lintas/konversi), StrategiLayananRegulasi (tarif teregulasi/lisensi); semua belum dikompilasi
- [x] M-042..M-047 (F7 selesai) domain/sdm: Kandidat.kt (jabatan eksekutif CEO/CFO/COO/CTO/CHRO, skorJabatan), Penggajian.kt (upah minimum per negara, pesangon), Turnover.kt (turnover vs gaji median), Otomatisasi.kt (efisiensi dari skor jabatan), Kompensasi.kt (bonus/opsi saham vesting), HubunganKerja.kt (kepuasan/risiko mogok); masing2 + test (3-4 uji); belum dikompilasi
- [x] M-048 (F8) data/src/aset.csv (kolom: kode,nama,jenis,negara,mata_uang,harga_awal_usd,volatilitas_tahunan_pct,imbal_pct,ukuran_lot,tanggal_data,perkiraan; jenis saham|komoditas|indeks|obligasi|kripto|properti; negara 2 huruf atau GLOBAL) + tools/gen_aset.py (validasi, diuji lokal) + JSON XAU. Baris XAU hanya CONTOH skema, harga 4000 bukan data nyata: isi aset sungguhan dari sumber bertanggal (perkiraan=true)
- [x] M-049 (F8) data/Aset.kt (model + dariJson, field kode/nama/jenis/negara/mataUang/hargaAwalUsd/volatilitasTahunanPct/imbalPct/ukuranLot/tanggalData/perkiraan) + data/AsetLoader.kt (muatSemua, urut kode); pola identik Usaha.kt/UsahaLoader.kt; dariJson tidak diuji unit (sama seperti Usaha); belum dikompilasi
- [x] M-050 (F8) domain/engine/HargaAset.kt (tick harga bulanan per aset: mean reversion ke hargaAwal + guncangan skala volatilitasTahunanPct/12, pola dari HargaKomoditas.kt) + HargaAsetTest (4 uji, acuan StrategiTambangEnergiTest); belum dikompilasi
- [x] M-051 (F8) domain/engine/Investasi.kt: beli/jual generik per aset (HasilTransaksiAset; bulatkan ke ukuranLot, unit kurang dari 1 lot diabaikan, biayaBrokerPct+pajakTransaksiPct desain game dari nilaiKotor; beli=nilaiKotor+biaya+pajak, jual=nilaiKotor-biaya-pajak) + InvestasiTest (4 uji); belum dikompilasi
- [x] M-052 (F8) domain/engine/Portofolio.kt: Kepemilikan(kodeAset,unit,hargaRataRata) + Portofolio.tambahBeli (average cost tertimbang dari nilaiBersih HasilTransaksiAset)/kurangiJual (unit tak boleh negatif, hargaRataRata tetap sampai unit 0 lalu reset)/labaRugiBelumTerealisasi + PortofolioTest (5 uji); belum dikompilasi
- [x] M-053 (F8) domain/engine/ImbalAset.kt: bayaranBulanan dari Aset.imbalPct tahunan (dividen/kupon/sewa) atas nilai beli posisi (bukan harga pasar, desain game), imbalPct<=0 -> 0; bayaranNBulan untuk kupon periodik + ImbalAsetTest (4 uji); belum dikompilasi
- [x] M-054 (F8, saham) domain/engine/CircuitBreaker.kt: batasi(hargaBaru,hargaKemarin,batasAtasPct=25,batasBawahPct=25) flat (bukan tiered IDX asli) + kenaAra/kenaArb deteksi; default ARA=ARB=25% + CircuitBreakerTest (6 uji); belum dikompilasi
- [x] M-055 (F8, saham) domain/engine/StockSplit.kt: terapkan(posisi,rasio) -> unit x rasio dibulatkan floor, hargaRataRata/rasio (nilai total tetap, sisa pecahan unit diabaikan bukan cash-in-lieu); rasio<=0 ditolak IllegalArgumentException + StockSplitTest (5 uji); belum dikompilasi
- [x] M-056 (F8, saham) domain/engine/DividenCumEx.kt: berhakDividen(bulanBeli,bulanCum,bulanJual=null) granularitas bulanan (bukan tanggal harian) -> berhak jika beli<=cum DAN (tidak dijual ATAU jual>cum; jual PADA bulanCum = ex-date, tidak berhak) + DividenCumExTest (6 uji); belum dikompilasi
- [x] M-057 (F8, saham SELESAI: lot+biaya+ARA/ARB+cum/ex+split+spread) domain/engine/SpreadBidAsk.kt: hargaBeli(ask)=hargaTengah x (1+spreadPct/200), hargaJual(bid)=hargaTengah x (1-spreadPct/200), half-spread tiap sisi + SpreadBidAskTest (5 uji); belum dikompilasi
- [x] M-058 (F8, obligasi) domain/engine/Obligasi.kt: kuponTahunan(nilaiPar,kuponPct), kuponPerPeriode(...,periodePerTahun), currentYieldPct(kuponTahunan,hargaPasar)=kupon/harga x100 + ObligasiTest (6 uji); belum dikompilasi. Belum: YTM, durasi
- [x] M-059 (F8, obligasi) Obligasi.ytmPerkiraanPct = (C+(F-P)/n)/((F+P)/2) x100, aproksimasi (bukan iteratif), require P,F,n>0 + 4 uji; belum dikompilasi
- [x] M-060 (F8, obligasi SELESAI: kupon+yield+YTM+durasi) Obligasi.hargaDariYtm (kupon tahunan, sisaTahun Int), durasiMacaulay, durasiModifikasi=Mac/(1+y) + 5 uji; nilai uji diverifikasi dengan Python; belum dikompilasi
- [x] M-061 (F8, deposito) domain/engine/Deposito.kt: bungaBruto (sederhana), jatuhTempo, pencairanDini (bunga sebagian, penalti % bunga, pokok utuh); HasilDeposito; pajak & penalti = parameter desain game + DepositoTest (6 uji); belum dikompilasi
- [x] M-062 (F8, reksa dana/ETF) domain/engine/ReksaDana.kt: navPerUnit, unitDariSubscribe, danaDariRedeem, navSetelahBiayaBulanan (biaya = parameter desain) + ReksaDanaTest (6 uji); belum dikompilasi
- [x] M-063 (F8, kripto) domain/engine/Kripto.kt: beliDenganDana/jual dengan unit pecahan Double, biaya % + biaya jaringan tetap (desain game), HasilKripto + KriptoTest (6 uji). Catatan: Kepemilikan.unit bertipe Int, posisi pecahan belum bisa disimpan; belum dikompilasi
- [x] M-064 (F8, kripto SELESAI) Kepemilikan.unit Int->Double; Portofolio.tambahBeliKripto/kurangiJualKripto (EPS_UNIT 1e-12 hindari residu); StockSplit floor tetap (Double); ImbalAset tak berubah; uji lama disesuaikan (literal Double) + 3 uji baru di PortofolioTest; belum dikompilasi
- [x] M-065 (F8, properti) domain/engine/Properti.kt: nilaiSetelahBulan (majemuk, pangkat bulan/12), totalBeli, bersihJual, biayaPemilikanBulanan, hargaJualCepat (diskon likuiditas); parameter = desain game; sewa lewat ImbalAset + PropertiTest (8 uji); belum dikompilasi
- [x] M-066 (F8, margin) domain/engine/Margin.kt: pinjamanDiperlukan, ekuitas, rasioMarginPct, kenaMarginCall (maintenance 25), danaTambahan, harusDilikuidasi (10), likuidasi -> HasilLikuidasi(diterima,kekurangan,biaya), bungaPinjamanBulanan; semua ambang = desain game + MarginTest (11 uji); belum dikompilasi
- [x] M-067 (F9, kredit) domain/engine/Kredit.kt: bungaPinjamanPct (acuan+premi), cicilanBulanan (PMT, bunga 0 -> bagi rata), jadwal (BarisCicilan; sisa akhir tepat 0), totalBunga; angka uji dari Python + KreditTest (9 uji); belum dikompilasi
- [x] M-068 (F9, premi risiko) domain/engine/PremiRisiko.kt: der/interestCoverage/currentRatio (penyebut<=0 -> tak hingga), poin 0..3 per rasio, premiPct = totalPoin x 0.75 (0..6.75), peringkat A..D; ambang = desain game + PremiRisikoTest (10 uji); belum dikompilasi
- [x] M-069 (F9, gagal bayar) domain/engine/GagalBayar.kt: dendaKeterlambatan (2%), status (LANCAR/MENUNGGAK/GAGAL_BAYAR, batas 3 bulan), restrukturisasi (biaya 1% ke pokok, tenor harus lebih panjang, cicilan via Kredit.cicilanBulanan) + GagalBayarTest (9 uji; cicilan uji dari Python); belum dikompilasi
- [x] M-070 (F9, obligasi korporasi) domain/engine/ObligasiKorporasi.kt: terbitkan (kupon=acuan+premi, biaya penerbitan 1%, dijual par), jadwalPembayaran (bullet: pokok di tahun terakhir), biayaDanaEfektifPct (via Obligasi.ytmPerkiraanPct) + ObligasiKorporasiTest (8 uji); belum dikompilasi
- [x] M-071 (F9, kredit valas) domain/engine/KreditValas.kt: danaRupiah, cicilanRupiah (PMT USD x kurs), cicilanRupiahPerBulan (kurs per bulan), labaRugiSelisihKurs = sisaUsd x (kursAwal-kursKini); kurs diberikan pemanggil (rupiah/USD); hedging belum + KreditValasTest (8 uji, angka dari Python); belum dikompilasi
- [x] M-072 (F9, covenant) domain/engine/Covenant.kt: Covenant(derMaks 3, coverageMin 2, currentRatioMin 1), CovenantEngine.periksa (batas tepat = aman), akibat (0 AMAN/1 BUNGA_NAIK/>=2 WAJIB_LUNAS), bungaSetelahPemeriksaan (+1%) + CovenantTest (9 uji); belum dikompilasi
- [x] M-073 (F9 SELESAI) domain/engine/Pendanaan.kt: UtangPerusahaan(nama,jenis,sisaPokok,bunga%,sisaTenorBulan), totalUtang (-> Neraca.utangBank), bebanBungaBulanan (x12 -> LaporanLabaRugi.biayaBunga), bungaRataRataPct, jatuhTempoTerdekatBulan, jatuhTempoDalam + PendanaanTest (7 uji); belum menyentuh Neraca/LabaRugi (hanya pembungkus); belum dikompilasi
- [x] M-074 (F10) data/src/rival.csv (60 rival Lampiran B: id,nama,sektor,negara,status,arketipe_utama,tanggal_data,perkiraan; 4 tertutup: Cargill, Koch, Djarum, Wings; Golden Agri=SG, Shell/Unilever/Rio=GB) + tools/gen_rival.py (validasi 60 baris/id/arketipe/negara/status; diuji lokal) -> 60 JSON di assets/data/rival; belum ada angka keuangan
- [x] M-075..M-076 (F10, id1-30) rival.csv +kolom kapitalisasi_usd_miliar,pendapatan_usd_miliar,margin_bersih_pct,utang_usd_miliar,sumber_kapitalisasi,catatan_angka (boleh kosong -> null); gen_rival.py parse+validasi. Kapitalisasi hanya id1-6,8 (investingcube.com 2026-10-05); lainnya kosong (tak ada sumber; companiesmarketcap tak boleh diakses). Pendapatan/margin/utang = perkiraan kasar dari pengetahuan model, belum diverifikasi (Glencore margin kosong; Toyota/VW utang termasuk pembiayaan)
- [ ] M-077..M-078 (F10; 077=id31-45, 078=46-60) isi kolom angka yang sama; Indonesia: angka dalam USD (kurs ~17.900 IDR/USD); kapitalisasi hanya bila ada sumber; tidak tahu -> kosong; tertutup: valuasi = pendapatan x multiple sektor (catat di catatan_angka)
- [ ] M-079 (F10) data/Rival.kt + RivalLoader.kt (pola Usaha.kt/UsahaLoader.kt); lalu mesin valuasi, AI aturan, akuisisi 2 arah (definisikan setelah M-079)

## Bug diketahui
(Build GitHub terbukti berhasil sampai M-012; layar ranking PDB tampil di HP. Jika build gagal, tempel log error.)
